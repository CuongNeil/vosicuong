﻿using System.ComponentModel.DataAnnotations;

namespace vosicuong.Models;

public class ParentChildLink
{
	public int Id { get; set; }

	[Required]
	public string ParentId { get; set; } = string.Empty;

	[Required]
	public string ChildId { get; set; } = string.Empty;

	public DateTime LinkedAt { get; set; } = DateTime.UtcNow;
}