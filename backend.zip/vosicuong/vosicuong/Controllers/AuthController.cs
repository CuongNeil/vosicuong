﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using vosicuong.Data;
using vosicuong.DTOs;
using vosicuong.Models;
using vosicuong.Services;

namespace vosicuong.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class AuthController : ControllerBase
	{
		private readonly UserManager<IdentityUser> _userManager;
		private readonly RoleManager<IdentityRole> _roleManager;
		private readonly IConfiguration _config;
		private readonly IEmailService _emailService;
		private readonly ApplicationDbContext _context;

		public AuthController(
			UserManager<IdentityUser> userManager,
			RoleManager<IdentityRole> roleManager,
			IConfiguration config,
			IEmailService emailService,
			ApplicationDbContext context)
		{
			_userManager = userManager;
			_roleManager = roleManager;
			_config = config;
			_emailService = emailService;
			_context = context;
		}

		// 1. Đăng ký tài khoản bằng ASP.NET Core Identity
		[HttpPost("register")]
		public async Task<IActionResult> Register([FromBody] RegisterDto dto)
		{
			var userExists = await _userManager.FindByEmailAsync(dto.Email);
			if (userExists != null)
				return BadRequest("Email này đã được sử dụng.");

			var user = new IdentityUser
			{
				Email = dto.Email,
				UserName = dto.Email
			};

			var result = await _userManager.CreateAsync(user, dto.Password);
			if (!result.Succeeded)
				return BadRequest(result.Errors);

			// Kiểm tra và tạo Role nếu chưa tồn tại
			if (!await _roleManager.RoleExistsAsync(dto.Role))
			{
				await _roleManager.CreateAsync(new IdentityRole(dto.Role));
			}

			await _userManager.AddToRoleAsync(user, dto.Role);

			return Ok(new { Message = "Đăng ký tài khoản thành công qua ASP.NET Core Identity." });
		}

		// 2. Đăng nhập + Sinh mã OTP bằng Two-Factor Token Provider của Identity
		[HttpPost("login")]
		public async Task<IActionResult> Login([FromBody] LoginDto dto)
		{
			var user = await _userManager.FindByEmailAsync(dto.Email);
			if (user == null || !await _userManager.CheckPasswordAsync(user, dto.Password))
				return Unauthorized("Tài khoản hoặc mật khẩu không chính xác.");

			// Sinh mã OTP chuẩn 6 chữ số bằng Identity Provider
			string otpCode = await _userManager.GenerateTwoFactorTokenAsync(user, "Email");

			// Gửi OTP qua Email
			string emailBody = $@"
                <div style='font-family: Arial, sans-serif; padding: 20px;'>
                    <h2>Xác thực đăng nhập ASP.NET Core Identity</h2>
                    <p>Mã OTP của bạn là: <b style='font-size: 24px; color: #2d89ef;'>{otpCode}</b></p>
                    <p>Mã xác thực có hiệu lực trong thời gian ngắn. Vui lòng không chia sẻ mã này.</p>
                </div>";

			await _emailService.SendEmailAsync(user.Email!, "Mã OTP Xác Thực Đăng Nhập", emailBody);

			return Ok(new { Message = "Mã OTP thực tế đã được gửi về Email của bạn.", RequiresOtp = true });
		}

		// 2b. Xác thực OTP
		[HttpPost("verify-otp")]
		public async Task<IActionResult> VerifyOtp([FromBody] VerifyOtpDto dto)
		{
			var user = await _userManager.FindByEmailAsync(dto.Email);
			if (user == null)
				return BadRequest("Yêu cầu không hợp lệ.");

			bool isValid = await _userManager.VerifyTwoFactorTokenAsync(user, "Email", dto.OtpCode);
			if (!isValid)
				return BadRequest("Mã OTP không hợp lệ hoặc đã hết hạn.");

			var roles = await _userManager.GetRolesAsync(user);
			string userRole = roles.FirstOrDefault() ?? "Parent";

			var token = GenerateJwtToken(user, userRole);
			return Ok(new AuthResponseDto
			{
				Token = token,
				Role = userRole,
				Email = user.Email!
			});
		}

		// 5a. Đăng nhập bằng khuôn mặt
		[HttpPost("face-login")]
		public async Task<IActionResult> FaceLogin([FromBody] FaceLoginDto dto)
		{
			var user = await _userManager.FindByIdAsync(dto.UserId);
			if (user == null) return NotFound("Người dùng không tồn tại.");

			var roles = await _userManager.GetRolesAsync(user);
			string userRole = roles.FirstOrDefault() ?? "Parent";

			var token = GenerateJwtToken(user, userRole);
			return Ok(new AuthResponseDto { Token = token, Role = userRole, Email = user.Email! });
		}

		private string GenerateJwtToken(IdentityUser user, string role)
		{
			var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
			var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

			var claims = new[]
			{
				new Claim(ClaimTypes.NameIdentifier, user.Id),
				new Claim(JwtRegisteredClaimNames.Email, user.Email!),
				new Claim(ClaimTypes.Role, role)
			};

			var token = new JwtSecurityToken(
				_config["Jwt:Issuer"],
				_config["Jwt:Audience"],
				claims,
				expires: DateTime.UtcNow.AddHours(8),
				signingCredentials: credentials);

			return new JwtSecurityTokenHandler().WriteToken(token);
		}
	}
}