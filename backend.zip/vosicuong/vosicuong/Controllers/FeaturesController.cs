﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.DTOs;
using vosicuong.Models;

namespace vosicuong.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	[Authorize]
	public class FeaturesController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public FeaturesController(ApplicationDbContext context)
		{
			_context = context;
		}

		// ==========================================
		// CRUD CHỨC NĂNG 5b: VỊ TRÍ
		// ==========================================

		[HttpPost("location")]
		public async Task<IActionResult> CreateLocation([FromBody] LocationCreateDto dto)
		{
			// Kiểm tra thiết bị có tồn tại trong CSDL trước khi thêm
			var deviceExists = await _context.ChildDevices.AnyAsync(d => d.Id == dto.ChildDeviceId);
			if (!deviceExists)
			{
				return BadRequest(new { Message = $"Không tìm thấy thiết bị với Id = {dto.ChildDeviceId}. Vui lòng kiểm tra lại!" });
			}

			var location = new LocationHistory
			{
				ChildDeviceId = dto.ChildDeviceId,
				Latitude = dto.Latitude,
				Longitude = dto.Longitude
			};

			_context.LocationHistories.Add(location);
			await _context.SaveChangesAsync();

			return Ok(new { Message = "Ghi nhận vị trí mới thành công.", Data = location });
		}

		[HttpGet("location")]
		public async Task<IActionResult> GetAllLocations()
		{
			var locations = await _context.LocationHistories
				.Include(l => l.ChildDevice)
				.ToListAsync();

			return Ok(locations);
		}

		[HttpPut("location/{id}")]
		public async Task<IActionResult> UpdateLocation(int id, [FromBody] LocationUpdateDto dto)
		{
			var location = await _context.LocationHistories.FindAsync(id);
			if (location == null) return NotFound("Không tìm thấy vị trí.");

			location.Latitude = dto.Latitude;
			location.Longitude = dto.Longitude;

			await _context.SaveChangesAsync();
			return Ok(location);
		}

		[HttpDelete("location/{id}")]
		public async Task<IActionResult> DeleteLocation(int id)
		{
			var location = await _context.LocationHistories.FindAsync(id);
			if (location == null) return NotFound("Không tìm thấy vị trí.");

			_context.LocationHistories.Remove(location);
			await _context.SaveChangesAsync();
			return Ok(new { Message = "Xóa vị trí thành công." });
		}

		// ==========================================
		// CRUD CHỨC NĂNG 5d & 6: TIẾNG ỒN & CẢNH BÁO
		// ==========================================

		[HttpPost("noise")]
		public async Task<IActionResult> RecordNoise([FromBody] NoiseCreateDto dto)
		{
			// Kiểm tra thiết bị có tồn tại trong CSDL trước khi thêm
			var deviceExists = await _context.ChildDevices.AnyAsync(d => d.Id == dto.ChildDeviceId);
			if (!deviceExists)
			{
				return BadRequest(new { Message = $"Không tìm thấy thiết bị với Id = {dto.ChildDeviceId}. Vui lòng kiểm tra lại!" });
			}

			bool isDangerous = dto.DecibelLevel > 85.0f; // Cảnh báo thông minh (>85dB)

			var noiseLog = new NoiseLog
			{
				ChildDeviceId = dto.ChildDeviceId,
				DecibelLevel = dto.DecibelLevel,
				IsDangerous = isDangerous
			};

			_context.NoiseLogs.Add(noiseLog);
			await _context.SaveChangesAsync();

			return Ok(new
			{
				Alert = isDangerous,
				Message = isDangerous ? "CẢNH BÁO: Tiếng ồn vượt ngưỡng an toàn!" : "Mức tiếng ồn an toàn.",
				Data = noiseLog
			});
		}

		[HttpGet("noise")]
		public async Task<IActionResult> GetAllNoiseLogs()
		{
			var logs = await _context.NoiseLogs
				.Include(n => n.ChildDevice)
				.ToListAsync();

			return Ok(logs);
		}

		[HttpPut("noise/{id}")]
		public async Task<IActionResult> UpdateNoiseLog(int id, [FromBody] NoiseUpdateDto dto)
		{
			var noiseLog = await _context.NoiseLogs.FindAsync(id);
			if (noiseLog == null) return NotFound("Không tìm thấy bản ghi.");

			noiseLog.DecibelLevel = dto.DecibelLevel;
			noiseLog.IsDangerous = dto.DecibelLevel > 85.0f;

			await _context.SaveChangesAsync();
			return Ok(noiseLog);
		}

		[HttpDelete("noise/{id}")]
		public async Task<IActionResult> DeleteNoiseLog(int id)
		{
			var noiseLog = await _context.NoiseLogs.FindAsync(id);
			if (noiseLog == null) return NotFound("Không tìm thấy bản ghi.");

			_context.NoiseLogs.Remove(noiseLog);
			await _context.SaveChangesAsync();
			return Ok(new { Message = "Xóa nhật ký tiếng ồn thành công." });
		}
	}
}