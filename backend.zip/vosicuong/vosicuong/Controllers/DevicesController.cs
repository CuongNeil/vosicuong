﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.DTOs;
using vosicuong.Models;

namespace vosicuong.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	[Authorize]
	public class DevicesController : ControllerBase
	{
		private readonly ApplicationDbContext _context;

		public DevicesController(ApplicationDbContext context)
		{
			_context = context;
		}

		// 1. CREATE
		[HttpPost]
		public async Task<IActionResult> Create([FromBody] ChildDeviceCreateDto dto)
		{
			var device = new ChildDevice
			{
				DeviceName = dto.DeviceName,
				DeviceCode = dto.DeviceCode,
				ParentId = dto.ParentId
			};

			_context.ChildDevices.Add(device);
			await _context.SaveChangesAsync();
			return CreatedAtAction(nameof(GetById), new { id = device.Id }, device);
		}

		// 2. READ ALL
		[HttpGet]
		public async Task<IActionResult> GetAll()
		{
			var devices = await _context.ChildDevices.Include(d => d.Parent).ToListAsync();
			return Ok(devices);
		}

		// READ BY ID
		[HttpGet("{id}")]
		public async Task<IActionResult> GetById(int id)
		{
			var device = await _context.ChildDevices.Include(d => d.Parent).FirstOrDefaultAsync(d => d.Id == id);
			if (device == null) return NotFound("Không tìm thấy thiết bị.");
			return Ok(device);
		}

		// 3. UPDATE
		[HttpPut("{id}")]
		public async Task<IActionResult> Update(int id, [FromBody] ChildDeviceUpdateDto dto)
		{
			var device = await _context.ChildDevices.FindAsync(id);
			if (device == null) return NotFound("Không tìm thấy thiết bị.");

			device.DeviceName = dto.DeviceName;
			device.DeviceCode = dto.DeviceCode;

			await _context.SaveChangesAsync();
			return Ok(device);
		}

		// 4. DELETE
		[HttpDelete("{id}")]
		public async Task<IActionResult> Delete(int id)
		{
			var device = await _context.ChildDevices.FindAsync(id);
			if (device == null) return NotFound("Không tìm thấy thiết bị.");

			_context.ChildDevices.Remove(device);
			await _context.SaveChangesAsync();
			return Ok(new { Message = "Xóa thiết bị thành công." });
		}
	}
}