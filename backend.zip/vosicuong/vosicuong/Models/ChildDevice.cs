﻿
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace vosicuong.Models;

public class ChildDevice
{
	public int Id { get; set; }

	[Required]
	[MaxLength(100)]
	public string DeviceName { get; set; } = string.Empty;

	[Required]
	[MaxLength(32)]
	public string DeviceCode { get; set; } = string.Empty;

	public string? ParentId { get; set; }

	public IdentityUser? Parent { get; set; }

	public string? ChildUserId { get; set; }

	public IdentityUser? ChildUser { get; set; }

	public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
