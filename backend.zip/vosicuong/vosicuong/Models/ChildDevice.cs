﻿using Microsoft.AspNetCore.Identity;

namespace vosicuong.Models
{
	public class ChildDevice
	{
		public int Id { get; set; }
		public string DeviceName { get; set; } = string.Empty;
		public string DeviceCode { get; set; } = string.Empty;

		// Thay ParentId từ int sang string để map với IdentityUser.Id
		public string ParentId { get; set; } = string.Empty;
		public IdentityUser Parent { get; set; } = null!;

		public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
	}
}
