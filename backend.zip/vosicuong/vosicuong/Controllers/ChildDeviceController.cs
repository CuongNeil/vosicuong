﻿
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.Models;

namespace vosicuong.Controllers;

[ApiController]
[Route("api/ChildDevice")]
[Authorize(Roles = "Child")]
public class ChildDeviceController : ControllerBase
{
	private readonly ApplicationDbContext _context;

	public ChildDeviceController(ApplicationDbContext context)
	{
		_context = context;
	}

	public class RegisterDeviceRequest
	{
		[Required(ErrorMessage = "Vui lòng nhập tên thiết bị.")]
		[StringLength(100, MinimumLength = 1, ErrorMessage = "Tên thiết bị phải từ 1 đến 100 ký tự.")]
		public string DeviceName { get; set; } = string.Empty;
	}

	[HttpGet("my-device")]
	public async Task<IActionResult> GetMyDevice(CancellationToken cancellationToken)
	{
		var childUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);

		if (string.IsNullOrWhiteSpace(childUserId))
			return Unauthorized(new { message = "Không xác định được tài khoản Child." });

		var device = await _context.ChildDevices
			.AsNoTracking()
			.Where(d => d.ChildUserId == childUserId)
			.OrderByDescending(d => d.CreatedAt)
			.Select(d => new
			{
				deviceId = d.Id,
				deviceName = d.DeviceName,
				deviceCode = d.DeviceCode,
				createdAt = d.CreatedAt
			})
			.FirstOrDefaultAsync(cancellationToken);

		if (device == null)
			return NotFound(new { message = "Tài khoản Child chưa được đăng ký điện thoại." });

		return Ok(device);
	}

	[HttpPost("register")]
	public async Task<IActionResult> RegisterDevice(
		[FromBody] RegisterDeviceRequest request,
		CancellationToken cancellationToken)
	{
		var childUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);

		if (string.IsNullOrWhiteSpace(childUserId))
			return Unauthorized(new { message = "Không xác định được tài khoản Child." });

		var deviceName = request.DeviceName?.Trim();

		if (string.IsNullOrWhiteSpace(deviceName))
			return BadRequest(new { message = "Vui lòng nhập tên thiết bị." });

		if (deviceName.Length > 100)
			return BadRequest(new { message = "Tên thiết bị không được vượt quá 100 ký tự." });

		var existingDevice = await _context.ChildDevices
			.AsNoTracking()
			.Where(d => d.ChildUserId == childUserId)
			.OrderByDescending(d => d.CreatedAt)
			.FirstOrDefaultAsync(cancellationToken);

		if (existingDevice != null)
		{
			return Ok(new
			{
				message = "Tài khoản Child đã đăng ký thiết bị.",
				deviceId = existingDevice.Id,
				deviceName = existingDevice.DeviceName,
				deviceCode = existingDevice.DeviceCode,
				createdAt = existingDevice.CreatedAt
			});
		}

		var device = new ChildDevice
		{
			ChildUserId = childUserId,
			ParentId = null,
			DeviceName = deviceName,
			DeviceCode = Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
			CreatedAt = DateTime.UtcNow
		};

		_context.ChildDevices.Add(device);
		await _context.SaveChangesAsync(cancellationToken);

		return Ok(new
		{
			message = "Đăng ký thiết bị thành công.",
			deviceId = device.Id,
			deviceName = device.DeviceName,
			deviceCode = device.DeviceCode,
			createdAt = device.CreatedAt
		});
	}
}
