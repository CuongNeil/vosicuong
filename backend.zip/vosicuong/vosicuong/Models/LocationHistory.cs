﻿namespace vosicuong.Models
{
	public class LocationHistory
	{
		public int Id { get; set; }
		public int ChildDeviceId { get; set; }
		public ChildDevice ChildDevice { get; set; } = null!;
		public double Latitude { get; set; }
		public double Longitude { get; set; }
		public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
	}
}
