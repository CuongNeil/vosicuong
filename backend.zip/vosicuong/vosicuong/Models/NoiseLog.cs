﻿namespace vosicuong.Models
{
	public class NoiseLog
	{
		public int Id { get; set; }
		public int ChildDeviceId { get; set; }
		public ChildDevice ChildDevice { get; set; } = null!;
		public float DecibelLevel { get; set; } // Mức tiếng ồn (dB)
		public bool IsDangerous { get; set; }
		public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
	}
}
