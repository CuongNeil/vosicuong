﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using vosicuong.Models;

namespace vosicuong.Data
{
	public class ApplicationDbContext : IdentityDbContext<IdentityUser>
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options) { }

		public DbSet<ChildDevice> ChildDevices { get; set; }
		public DbSet<LocationHistory> LocationHistories { get; set; }
		public DbSet<NoiseLog> NoiseLogs { get; set; }
		public DbSet<FaceData> FaceDatas { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<FaceData>(entity =>
			{
				entity.HasKey(f => f.Id);

				entity.Property(f => f.UserId)
					.IsRequired();

				entity.Property(f => f.FaceVector)
					.IsRequired();

				entity.HasOne(f => f.User)
					.WithMany()
					.HasForeignKey(f => f.UserId)
					.OnDelete(DeleteBehavior.Cascade);

				entity.HasIndex(f => f.UserId)
					.IsUnique();
			});

			modelBuilder.Entity<IdentityRole>().HasData(
				new IdentityRole
				{
					Id = "1",
					Name = "Admin",
					NormalizedName = "ADMIN",
					ConcurrencyStamp = "c8f2887a-251d-4f1d-b873-198d02fa7b11"
				},
				new IdentityRole
				{
					Id = "2",
					Name = "Staff",
					NormalizedName = "STAFF",
					ConcurrencyStamp = "f4e3892a-392b-4d2c-a218-912b304f8c22"
				},
				new IdentityRole
				{
					Id = "3",
					Name = "Parent",
					NormalizedName = "PARENT",
					ConcurrencyStamp = "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"
				},
				new IdentityRole
				{
					Id = "4",
					Name = "Child",
					NormalizedName = "CHILD",
					ConcurrencyStamp = "e9f8d7c6-b5a4-3f2e-1d0c-9b8a7f6e5d4c"
				}
			);
		}
	}
}