﻿using System.ComponentModel.DataAnnotations;

namespace vosicuong.Models;

public class DeviceControlPolicy
{
	public int Id { get; set; }
	public int ChildDeviceId { get; set; }
	public ChildDevice? ChildDevice { get; set; }
	public bool IsDeviceLocked { get; set; } = false;
	[Range(0, 1440)]
	public int DailyLimitMinutes { get; set; } = 120;
	public TimeSpan? AllowedStartTime { get; set; }
	public TimeSpan? AllowedEndTime { get; set; }
	public bool AppAllowListEnabled { get; set; } = false;
	public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
	public string? UpdatedByParentId { get; set; }
}