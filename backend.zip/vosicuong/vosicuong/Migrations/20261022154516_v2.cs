﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace vosicuong.Migrations
{
    /// <inheritdoc />
    public partial class v2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_FaceDatas_UserId",
                table: "FaceDatas");

            migrationBuilder.AddColumn<string>(
                name: "ChildUserId",
                table: "ChildDevices",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ParentChildInvitations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ParentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CodeHash = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                    ExpiresAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParentChildInvitations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ParentChildInvitations_AspNetUsers_ParentId",
                        column: x => x.ParentId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ParentChildLinks",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ParentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ChildId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LinkedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParentChildLinks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ParentChildLinks_AspNetUsers_ChildId",
                        column: x => x.ChildId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ParentChildLinks_AspNetUsers_ParentId",
                        column: x => x.ParentId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FaceDatas_UserId",
                table: "FaceDatas",
                column: "UserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ChildDevices_ChildUserId",
                table: "ChildDevices",
                column: "ChildUserId",
                unique: true,
                filter: "[ChildUserId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_ParentChildInvitations_CodeHash",
                table: "ParentChildInvitations",
                column: "CodeHash",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ParentChildInvitations_ParentId",
                table: "ParentChildInvitations",
                column: "ParentId");

            migrationBuilder.CreateIndex(
                name: "IX_ParentChildLinks_ChildId",
                table: "ParentChildLinks",
                column: "ChildId");

            migrationBuilder.CreateIndex(
                name: "IX_ParentChildLinks_ParentId_ChildId",
                table: "ParentChildLinks",
                columns: new[] { "ParentId", "ChildId" },
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ChildDevices_AspNetUsers_ChildUserId",
                table: "ChildDevices",
                column: "ChildUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ChildDevices_AspNetUsers_ChildUserId",
                table: "ChildDevices");

            migrationBuilder.DropTable(
                name: "ParentChildInvitations");

            migrationBuilder.DropTable(
                name: "ParentChildLinks");

            migrationBuilder.DropIndex(
                name: "IX_FaceDatas_UserId",
                table: "FaceDatas");

            migrationBuilder.DropIndex(
                name: "IX_ChildDevices_ChildUserId",
                table: "ChildDevices");

            migrationBuilder.DropColumn(
                name: "ChildUserId",
                table: "ChildDevices");

            migrationBuilder.CreateIndex(
                name: "IX_FaceDatas_UserId",
                table: "FaceDatas",
                column: "UserId");
        }
    }
}
