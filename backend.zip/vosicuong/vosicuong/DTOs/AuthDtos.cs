﻿namespace vosicuong.DTOs
{
	public class RegisterDto
	{
		public string Email { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;
		public string FullName { get; set; } = string.Empty;
		public string Role { get; set; } = "Parent"; // "Admin", "Staff", "Parent", "Child"
	}

	public class LoginDto
	{
		public string Email { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;
	}

	public class VerifyOtpDto
	{
		public string Email { get; set; } = string.Empty;
		public string OtpCode { get; set; } = string.Empty;
	}

	public class FaceLoginDto
	{
		public string UserId { get; set; } = string.Empty; // IdentityUser.Id dạng string (GUID)
		public string FaceVector { get; set; } = string.Empty;
	}

	public class AuthResponseDto
	{
		public string Token { get; set; } = string.Empty;
		public string Role { get; set; } = string.Empty;
		public string Email { get; set; } = string.Empty;
	}
}