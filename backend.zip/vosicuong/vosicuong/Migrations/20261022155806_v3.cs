﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace vosicuong.Migrations
{
    /// <inheritdoc />
    public partial class v3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LocationHistories");

            migrationBuilder.DropTable(
                name: "NoiseLogs");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LocationHistories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChildDeviceId = table.Column<int>(type: "int", nullable: false),
                    Latitude = table.Column<double>(type: "float", nullable: false),
                    Longitude = table.Column<double>(type: "float", nullable: false),
                    RecordedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LocationHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LocationHistories_ChildDevices_ChildDeviceId",
                        column: x => x.ChildDeviceId,
                        principalTable: "ChildDevices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "NoiseLogs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChildDeviceId = table.Column<int>(type: "int", nullable: false),
                    DecibelLevel = table.Column<float>(type: "real", nullable: false),
                    IsDangerous = table.Column<bool>(type: "bit", nullable: false),
                    RecordedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NoiseLogs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_NoiseLogs_ChildDevices_ChildDeviceId",
                        column: x => x.ChildDeviceId,
                        principalTable: "ChildDevices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LocationHistories_ChildDeviceId",
                table: "LocationHistories",
                column: "ChildDeviceId");

            migrationBuilder.CreateIndex(
                name: "IX_NoiseLogs_ChildDeviceId",
                table: "NoiseLogs",
                column: "ChildDeviceId");
        }
    }
}
