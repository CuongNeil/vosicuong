﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace vosicuong.Migrations
{
    /// <inheritdoc />
    public partial class v4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppControlRules",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChildDeviceId = table.Column<int>(type: "int", nullable: false),
                    PackageName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    AppName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    IsAllowed = table.Column<bool>(type: "bit", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppControlRules", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AppControlRules_ChildDevices_ChildDeviceId",
                        column: x => x.ChildDeviceId,
                        principalTable: "ChildDevices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DeviceControlPolicies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChildDeviceId = table.Column<int>(type: "int", nullable: false),
                    IsDeviceLocked = table.Column<bool>(type: "bit", nullable: false),
                    DailyLimitMinutes = table.Column<int>(type: "int", nullable: false),
                    AllowedStartTime = table.Column<TimeSpan>(type: "time", nullable: true),
                    AllowedEndTime = table.Column<TimeSpan>(type: "time", nullable: true),
                    AppAllowListEnabled = table.Column<bool>(type: "bit", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedByParentId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeviceControlPolicies", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DeviceControlPolicies_ChildDevices_ChildDeviceId",
                        column: x => x.ChildDeviceId,
                        principalTable: "ChildDevices",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppControlRules_ChildDeviceId_PackageName",
                table: "AppControlRules",
                columns: new[] { "ChildDeviceId", "PackageName" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DeviceControlPolicies_ChildDeviceId",
                table: "DeviceControlPolicies",
                column: "ChildDeviceId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppControlRules");

            migrationBuilder.DropTable(
                name: "DeviceControlPolicies");
        }
    }
}
