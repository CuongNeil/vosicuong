﻿using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.Models;

namespace vosicuong.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin,Parent")]
public class DevicesController : ControllerBase
{
	private readonly ApplicationDbContext _context;
	private readonly UserManager<IdentityUser> _userManager;

	public DevicesController(
		ApplicationDbContext context,
		UserManager<IdentityUser> userManager)
	{
		_context = context;
		_userManager = userManager;
	}

	private string? CurrentUserId =>
		User.FindFirstValue(ClaimTypes.NameIdentifier);

	private bool IsAdmin => User.IsInRole("Admin");

	private IQueryable<ChildDevice> AccessibleDevices()
	{
		var query = _context.ChildDevices
			.Include(d => d.Parent)
			.AsQueryable();

		if (!IsAdmin)
		{
			var userId = CurrentUserId;
			query = query.Where(d => d.ParentId == userId);
		}

		return query;
	}

	private static object ToResponse(ChildDevice device)
	{
		return new
		{
			device.Id,
			device.DeviceName,
			device.DeviceCode,
			device.ParentId,
			ParentEmail = device.Parent != null ? device.Parent.Email : null,
			device.ChildUserId,
			device.CreatedAt
		};
	}

	private async Task<string> GenerateDeviceCodeAsync()
	{
		const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

		while (true)
		{
			var bytes = RandomNumberGenerator.GetBytes(8);
			var code = new string(
				bytes.Select(b => chars[b % chars.Length]).ToArray());

			if (!await _context.ChildDevices.AnyAsync(d => d.DeviceCode == code))
				return code;
		}
	}

	[HttpGet]
	public async Task<IActionResult> GetDevices()
	{
		if (string.IsNullOrWhiteSpace(CurrentUserId))
			return Unauthorized();

		var devices = await AccessibleDevices()
			.AsNoTracking()
			.OrderByDescending(d => d.CreatedAt)
			.ToListAsync();

		return Ok(devices.Select(ToResponse));
	}

	[HttpGet("{id:int}")]
	public async Task<IActionResult> GetDevice(int id)
	{
		if (string.IsNullOrWhiteSpace(CurrentUserId))
			return Unauthorized();

		var device = await AccessibleDevices()
			.AsNoTracking()
			.FirstOrDefaultAsync(d => d.Id == id);

		if (device == null)
			return NotFound(new
			{
				Message = "Không tìm thấy thiết bị hoặc bạn không có quyền truy cập."
			});

		return Ok(ToResponse(device));
	}

	[HttpPost]
	public async Task<IActionResult> CreateDevice(
		[FromBody] DeviceCreateRequest request)
	{
		if (string.IsNullOrWhiteSpace(CurrentUserId))
			return Unauthorized();

		if (string.IsNullOrWhiteSpace(request.DeviceName))
			return BadRequest(new
			{
				Message = "Tên thiết bị không được để trống."
			});

		string parentId;

		if (IsAdmin)
		{
			if (string.IsNullOrWhiteSpace(request.ParentId))
				return BadRequest(new
				{
					Message = "Admin phải chọn tài khoản phụ huynh."
				});

			var parent = await _userManager.FindByIdAsync(request.ParentId);

			if (parent == null ||
				!await _userManager.IsInRoleAsync(parent, "Parent"))
			{
				return BadRequest(new
				{
					Message = "Tài khoản phụ huynh không hợp lệ."
				});
			}

			parentId = parent.Id;
		}
		else
		{
			parentId = CurrentUserId;
		}

		var device = new ChildDevice
		{
			DeviceName = request.DeviceName.Trim(),
			DeviceCode = await GenerateDeviceCodeAsync(),
			ParentId = parentId,
			CreatedAt = DateTime.UtcNow
		};

		_context.ChildDevices.Add(device);
		await _context.SaveChangesAsync();
		await _context.Entry(device).Reference(d => d.Parent).LoadAsync();

		return CreatedAtAction(
			nameof(GetDevice),
			new { id = device.Id },
			ToResponse(device));
	}

	[HttpPut("{id:int}")]
	public async Task<IActionResult> UpdateDevice(
		int id,
		[FromBody] DeviceUpdateRequest request)
	{
		if (string.IsNullOrWhiteSpace(CurrentUserId))
			return Unauthorized();

		if (string.IsNullOrWhiteSpace(request.DeviceName))
			return BadRequest(new
			{
				Message = "Tên thiết bị không được để trống."
			});

		var device = await AccessibleDevices()
			.FirstOrDefaultAsync(d => d.Id == id);

		if (device == null)
			return NotFound(new
			{
				Message = "Không tìm thấy thiết bị hoặc bạn không có quyền sửa."
			});

		device.DeviceName = request.DeviceName.Trim();

		await _context.SaveChangesAsync();

		return Ok(new
		{
			Message = "Cập nhật thiết bị thành công.",
			Data = ToResponse(device)
		});
	}

	[HttpDelete("{id:int}")]
	public async Task<IActionResult> DeleteDevice(int id)
	{
		if (string.IsNullOrWhiteSpace(CurrentUserId))
			return Unauthorized();

		var device = await AccessibleDevices()
			.FirstOrDefaultAsync(d => d.Id == id);

		if (device == null)
			return NotFound(new
			{
				Message = "Không tìm thấy thiết bị hoặc bạn không có quyền xóa."
			});

		_context.ChildDevices.Remove(device);
		await _context.SaveChangesAsync();

		return Ok(new { Message = "Xóa thiết bị thành công." });
	}
}

public class DeviceCreateRequest
{
	public string DeviceName { get; set; } = string.Empty;
	public string? ParentId { get; set; }
}

public class DeviceUpdateRequest
{
	public string DeviceName { get; set; } = string.Empty;
}