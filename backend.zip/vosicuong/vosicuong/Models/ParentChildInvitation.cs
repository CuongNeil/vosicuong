﻿using System.ComponentModel.DataAnnotations;

namespace vosicuong.Models;

public class ParentChildInvitation
{
	public int Id { get; set; }

	[Required]
	public string ParentId { get; set; } = string.Empty;

	[Required]
	[MaxLength(64)]
	public string CodeHash { get; set; } = string.Empty;

	public DateTime ExpiresAt { get; set; }

	public DateTime? UsedAt { get; set; }

	public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}