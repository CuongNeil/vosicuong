﻿using System.ComponentModel.DataAnnotations;

namespace vosicuong.Models;

public class AppControlRule
{
	public int Id { get; set; }
	public int ChildDeviceId { get; set; }
	public ChildDevice? ChildDevice { get; set; }
	[Required, MaxLength(255)]
	public string PackageName { get; set; } = string.Empty;
	[MaxLength(255)]
	public string AppName { get; set; } = string.Empty;
	public bool IsAllowed { get; set; }
	public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}