﻿namespace vosicuong.DTOs
{
	// DTOs cho User
	public class UserCreateDto
	{
		public string Email { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;
		public string Role { get; set; } = "Parent";
	}

	public class UserUpdateDto
	{
		public string Email { get; set; } = string.Empty;
		public string PhoneNumber { get; set; } = string.Empty;
	}

	// DTOs cho ChildDevice
	public class ChildDeviceCreateDto
	{
		public string DeviceName { get; set; } = string.Empty;
		public string DeviceCode { get; set; } = string.Empty;
		public string ParentId { get; set; } = string.Empty;
	}

	public class ChildDeviceUpdateDto
	{
		public string DeviceName { get; set; } = string.Empty;
		public string DeviceCode { get; set; } = string.Empty;
	}

	// DTOs cho LocationHistory
	public class LocationCreateDto
	{
		public int ChildDeviceId { get; set; }
		public double Latitude { get; set; }
		public double Longitude { get; set; }
	}

	public class LocationUpdateDto
	{
		public double Latitude { get; set; }
		public double Longitude { get; set; }
	}

	// DTOs cho NoiseLog
	public class NoiseCreateDto
	{
		public int ChildDeviceId { get; set; }
		public float DecibelLevel { get; set; }
	}

	public class NoiseUpdateDto
	{
		public float DecibelLevel { get; set; }
	}
}