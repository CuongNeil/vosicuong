﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.Models;

namespace vosicuong.Controllers;

[ApiController]
[Route("api/Devices/{deviceId:int}")]
[Authorize(Roles = "Admin,Parent,Child")]
public class DevicePoliciesController : ControllerBase
{
	private readonly ApplicationDbContext _db;

	public DevicePoliciesController(ApplicationDbContext db)
	{
		_db = db;
	}

	private string UserId =>
		User.FindFirstValue(ClaimTypes.NameIdentifier)
		?? throw new UnauthorizedAccessException();

	private bool IsAdmin => User.IsInRole("Admin");
	private bool IsChild => User.IsInRole("Child");

	private async Task<ChildDevice?> AccessibleDevice(int deviceId)
	{
		var device = await _db.ChildDevices
			.FirstOrDefaultAsync(x => x.Id == deviceId);

		if (device == null) return null;
		if (IsAdmin) return device;

		if (IsChild)
			return device.ChildUserId == UserId ? device : null;

		if (device.ParentId == UserId)
			return device;

		if (string.IsNullOrEmpty(device.ChildUserId))
			return null;

		var linked = await _db.ParentChildLinks.AnyAsync(x =>
			x.ParentId == UserId &&
			x.ChildId == device.ChildUserId);

		return linked ? device : null;
	}

	private async Task<DeviceControlPolicy> GetOrCreatePolicy(int deviceId)
	{
		var policy = await _db.DeviceControlPolicies
			.FirstOrDefaultAsync(x => x.ChildDeviceId == deviceId);

		if (policy != null) return policy;

		policy = new DeviceControlPolicy { ChildDeviceId = deviceId };
		_db.DeviceControlPolicies.Add(policy);
		await _db.SaveChangesAsync();
		return policy;
	}

	[HttpGet("policy")]
	public async Task<IActionResult> GetPolicy(int deviceId)
	{
		var device = await AccessibleDevice(deviceId);
		if (device == null) return NotFound(new { Message = "Không tìm thấy thiết bị hoặc bạn không có quyền truy cập." });

		var policy = await GetOrCreatePolicy(deviceId);
		return Ok(policy);
	}

	[HttpPut("policy")]
	[Authorize(Roles = "Admin,Parent")]
	public async Task<IActionResult> UpdatePolicy(
		int deviceId, [FromBody] UpdateDevicePolicyRequest request)
	{
		var device = await AccessibleDevice(deviceId);
		if (device == null) return NotFound(new { Message = "Không tìm thấy thiết bị hoặc bạn không có quyền truy cập." });

		if (request.DailyLimitMinutes < 0 || request.DailyLimitMinutes > 1440)
			return BadRequest(new { Message = "DailyLimitMinutes phải từ 0 đến 1440." });

		if (request.AllowedStartTime.HasValue != request.AllowedEndTime.HasValue)
			return BadRequest(new { Message = "Phải nhập cả giờ bắt đầu và giờ kết thúc, hoặc để trống cả hai." });

		var policy = await GetOrCreatePolicy(deviceId);
		policy.IsDeviceLocked = request.IsDeviceLocked;
		policy.DailyLimitMinutes = request.DailyLimitMinutes;
		policy.AllowedStartTime = request.AllowedStartTime;
		policy.AllowedEndTime = request.AllowedEndTime;
		policy.AppAllowListEnabled = request.AppAllowListEnabled;
		policy.UpdatedAt = DateTime.UtcNow;
		policy.UpdatedByParentId = UserId;

		await _db.SaveChangesAsync();
		return Ok(new { Message = "Đã cập nhật chính sách thiết bị.", Policy = policy });
	}

	[HttpGet("app-rules")]
	public async Task<IActionResult> GetAppRules(int deviceId)
	{
		var device = await AccessibleDevice(deviceId);
		if (device == null) return NotFound(new { Message = "Không tìm thấy thiết bị hoặc bạn không có quyền truy cập." });

		var rules = await _db.AppControlRules
			.Where(x => x.ChildDeviceId == deviceId)
			.OrderBy(x => x.AppName)
			.ToListAsync();

		return Ok(rules);
	}

	[HttpPut("app-rules")]
	[Authorize(Roles = "Admin,Parent")]
	public async Task<IActionResult> ReplaceAppRules(
		int deviceId, [FromBody] ReplaceAppRulesRequest request)
	{
		var device = await AccessibleDevice(deviceId);
		if (device == null) return NotFound(new { Message = "Không tìm thấy thiết bị hoặc bạn không có quyền truy cập." });

		if (request.Rules == null)
			return BadRequest(new { Message = "Danh sách Rules không được null." });

		if (request.Rules.Any(x =>
			string.IsNullOrWhiteSpace(x.PackageName) ||
			x.PackageName.Length > 255 ||
			(x.AppName?.Length ?? 0) > 255))
			return BadRequest(new { Message = "Tên ứng dụng hoặc PackageName không hợp lệ." });

		if (request.Rules
			.GroupBy(x => x.PackageName.Trim(), StringComparer.OrdinalIgnoreCase)
			.Any(g => g.Count() > 1))
			return BadRequest(new { Message = "PackageName không được trùng lặp." });

		var existing = await _db.AppControlRules
			.Where(x => x.ChildDeviceId == deviceId)
			.ToListAsync();

		_db.AppControlRules.RemoveRange(existing);

		foreach (var item in request.Rules)
		{
			_db.AppControlRules.Add(new AppControlRule
			{
				ChildDeviceId = deviceId,
				PackageName = item.PackageName.Trim(),
				AppName = item.AppName?.Trim() ?? string.Empty,
				IsAllowed = item.IsAllowed,
				UpdatedAt = DateTime.UtcNow
			});
		}

		await _db.SaveChangesAsync();

		return Ok(new
		{
			Message = "Đã cập nhật danh sách ứng dụng.",
			Count = request.Rules.Count
		});
	}
}

public class UpdateDevicePolicyRequest
{
	public bool IsDeviceLocked { get; set; }
	public int DailyLimitMinutes { get; set; } = 120;
	public TimeSpan? AllowedStartTime { get; set; }
	public TimeSpan? AllowedEndTime { get; set; }
	public bool AppAllowListEnabled { get; set; }
}

public class ReplaceAppRulesRequest
{
	public List<AppControlRuleRequest> Rules { get; set; } = new();
}

public class AppControlRuleRequest
{
	public string PackageName { get; set; } = string.Empty;
	public string? AppName { get; set; }
	public bool IsAllowed { get; set; }
}
