﻿using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.Data;
using vosicuong.Models;

namespace vosicuong.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ParentChildController : ControllerBase
{
	private readonly ApplicationDbContext _db;
	private readonly UserManager<IdentityUser> _users;

	public ParentChildController(
		ApplicationDbContext db,
		UserManager<IdentityUser> users)
	{
		_db = db;
		_users = users;
	}

	private string CurrentUserId =>
		User.FindFirstValue(ClaimTypes.NameIdentifier)
		?? throw new UnauthorizedAccessException();

	private static string HashCode(string code)
	{
		return Convert.ToHexString(
			SHA256.HashData(Encoding.UTF8.GetBytes(code.Trim().ToUpperInvariant())));
	}

	[HttpPost("invitations")]
	[Authorize(Roles = "Parent")]
	public async Task<IActionResult> CreateInvitation()
	{
		var parentId = CurrentUserId;
		string code;
		string hash;

		do
		{
			code = Convert.ToHexString(RandomNumberGenerator.GetBytes(4));
			hash = HashCode(code);
		}
		while (await _db.ParentChildInvitations.AnyAsync(x => x.CodeHash == hash));

		var invitation = new ParentChildInvitation
		{
			ParentId = parentId,
			CodeHash = hash,
			ExpiresAt = DateTime.UtcNow.AddMinutes(15)
		};

		_db.ParentChildInvitations.Add(invitation);
		await _db.SaveChangesAsync();

		return Ok(new
		{
			Message = "Mã ghép nối đã được tạo.",
			Code = code,
			ExpiresAt = invitation.ExpiresAt
		});
	}

	[HttpPost("redeem")]
	[Authorize(Roles = "Child")]
	public async Task<IActionResult> RedeemInvitation(
		[FromBody] RedeemInvitationRequest request)
	{
		if (string.IsNullOrWhiteSpace(request.Code))
			return BadRequest(new { Message = "Vui lòng nhập mã ghép nối." });

		var childId = CurrentUserId;
		var hash = HashCode(request.Code);

		var invitation = await _db.ParentChildInvitations
			.FirstOrDefaultAsync(x => x.CodeHash == hash);

		if (invitation == null ||
			invitation.UsedAt != null ||
			invitation.ExpiresAt <= DateTime.UtcNow)
		{
			return BadRequest(new
			{
				Message = "Mã không hợp lệ, đã sử dụng hoặc hết hạn."
			});
		}

		if (invitation.ParentId == childId)
			return BadRequest(new { Message = "Không thể tự liên kết tài khoản." });

		var parent = await _users.FindByIdAsync(invitation.ParentId);
		if (parent == null || !await _users.IsInRoleAsync(parent, "Parent"))
			return BadRequest(new { Message = "Tài khoản Parent không hợp lệ." });

		var child = await _users.FindByIdAsync(childId);
		if (child == null || !await _users.IsInRoleAsync(child, "Child"))
			return Forbid();

		var alreadyLinked = await _db.ParentChildLinks.AnyAsync(x =>
			x.ParentId == invitation.ParentId && x.ChildId == childId);

		if (alreadyLinked)
			return Conflict(new { Message = "Hai tài khoản đã được liên kết." });

		invitation.UsedAt = DateTime.UtcNow;

		_db.ParentChildLinks.Add(new ParentChildLink
		{
			ParentId = invitation.ParentId,
			ChildId = childId
		});

		await _db.SaveChangesAsync();

		return Ok(new { Message = "Liên kết Parent–Child thành công." });
	}

	[HttpGet("my-children")]
	[Authorize(Roles = "Parent")]
	public async Task<IActionResult> GetMyChildren()
	{
		var parentId = CurrentUserId;

		var links = await _db.ParentChildLinks
			.Where(x => x.ParentId == parentId)
			.ToListAsync();

		var result = new List<object>();

		foreach (var link in links)
		{
			var child = await _users.FindByIdAsync(link.ChildId);
			if (child == null) continue;

			var device = await _db.ChildDevices
				.Where(x => x.ChildUserId == link.ChildId)
				.Select(x => new
				{
					x.Id,
					x.DeviceName,
					x.DeviceCode,
					x.CreatedAt
				})
				.FirstOrDefaultAsync();

			result.Add(new
			{
				ChildId = child.Id,
				Email = child.Email,
				link.LinkedAt,
				Device = device
			});
		}

		return Ok(result);
	}

	[HttpGet("my-parents")]
	[Authorize(Roles = "Child")]
	public async Task<IActionResult> GetMyParents()
	{
		var childId = CurrentUserId;

		var links = await _db.ParentChildLinks
			.Where(x => x.ChildId == childId)
			.ToListAsync();

		var result = new List<object>();

		foreach (var link in links)
		{
			var parent = await _users.FindByIdAsync(link.ParentId);
			if (parent == null) continue;

			result.Add(new
			{
				ParentId = parent.Id,
				Email = parent.Email,
				link.LinkedAt
			});
		}

		return Ok(result);
	}

	[HttpDelete("children/{childId}")]
	[Authorize(Roles = "Parent")]
	public async Task<IActionResult> UnlinkChild(string childId)
	{
		var parentId = CurrentUserId;

		var link = await _db.ParentChildLinks.FirstOrDefaultAsync(x =>
			x.ParentId == parentId && x.ChildId == childId);

		if (link == null)
			return NotFound(new { Message = "Không tìm thấy liên kết." });

		_db.ParentChildLinks.Remove(link);
		await _db.SaveChangesAsync();

		return Ok(new { Message = "Đã hủy liên kết với Child." });
	}

	[HttpDelete("parents/{parentId}")]
	[Authorize(Roles = "Child")]
	public async Task<IActionResult> UnlinkParent(string parentId)
	{
		var childId = CurrentUserId;

		var link = await _db.ParentChildLinks.FirstOrDefaultAsync(x =>
			x.ChildId == childId && x.ParentId == parentId);

		if (link == null)
			return NotFound(new { Message = "Không tìm thấy liên kết." });

		_db.ParentChildLinks.Remove(link);
		await _db.SaveChangesAsync();

		return Ok(new { Message = "Đã hủy liên kết với Parent." });
	}

	[HttpPost("register-device")]
	[Authorize(Roles = "Child")]
	public async Task<IActionResult> RegisterDevice(
		[FromBody] RegisterChildDeviceRequest request)
	{
		if (string.IsNullOrWhiteSpace(request.DeviceCode))
			return BadRequest(new { Message = "Vui lòng nhập mã thiết bị." });

		var childId = CurrentUserId;

		var device = await _db.ChildDevices
			.FirstOrDefaultAsync(x => x.DeviceCode == request.DeviceCode.Trim());

		if (device == null)
			return NotFound(new { Message = "Mã thiết bị không tồn tại." });

		var hasParentLink = await _db.ParentChildLinks.AnyAsync(x =>
			x.ChildId == childId && x.ParentId == device.ParentId);

		if (!hasParentLink)
			return Forbid();

		if (!string.IsNullOrEmpty(device.ChildUserId) &&
			device.ChildUserId != childId)
		{
			return Conflict(new
			{
				Message = "Thiết bị đã được liên kết với tài khoản Child khác."
			});
		}

		var existingDevice = await _db.ChildDevices.AnyAsync(x =>
			x.ChildUserId == childId && x.Id != device.Id);

		if (existingDevice)
			return Conflict(new
			{
				Message = "Tài khoản Child đã có điện thoại chính."
			});

		device.ChildUserId = childId;
		await _db.SaveChangesAsync();

		return Ok(new
		{
			Message = "Đã liên kết điện thoại chính.",
			device.Id,
			device.DeviceName,
			device.DeviceCode
		});
	}
}

public class RedeemInvitationRequest
{
	public string Code { get; set; } = string.Empty;
}

public class RegisterChildDeviceRequest
{
	public string DeviceCode { get; set; } = string.Empty;
}