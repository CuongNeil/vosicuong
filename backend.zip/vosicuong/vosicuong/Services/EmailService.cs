﻿using System.Net;
using System.Net.Mail;

namespace vosicuong.Services
{
	public class EmailService : IEmailService
	{
		private readonly IConfiguration _config;

		public EmailService(IConfiguration config)
		{
			_config = config;
		}

		public async Task SendEmailAsync(string toEmail, string subject, string body)
		{
			var smtpServer = _config["EmailSettings:SmtpServer"] ?? "smtp.gmail.com";
			var smtpPort = int.Parse(_config["EmailSettings:SmtpPort"] ?? "587");
			var senderEmail = _config["EmailSettings:SenderEmail"];
			var senderName = _config["EmailSettings:SenderName"] ?? "Child Management System";
			var smtpPass = _config["EmailSettings:SmtpPass"];

			using var client = new SmtpClient(smtpServer, smtpPort)
			{
				Credentials = new NetworkCredential(senderEmail, smtpPass),
				EnableSsl = true
			};

			var mailMessage = new MailMessage
			{
				From = new MailAddress(senderEmail!, senderName),
				Subject = subject,
				Body = body,
				IsBodyHtml = true
			};

			mailMessage.To.Add(toEmail);
			await client.SendMailAsync(mailMessage);
		}
	}
}
