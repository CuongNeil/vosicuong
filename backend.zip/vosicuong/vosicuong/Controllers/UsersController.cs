﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vosicuong.DTOs;

namespace vosicuong.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	[Authorize]
	public class UsersController : ControllerBase
	{
		private readonly UserManager<IdentityUser> _userManager;

		public UsersController(UserManager<IdentityUser> userManager)
		{
			_userManager = userManager;
		}

		// 3. Điều hướng trang theo Phân quyền
		[HttpGet("dashboard-redirect")]
		public IActionResult GetDashboardRedirect()
		{
			if (User.IsInRole("Admin"))
				return Ok(new { Target = "AdminDashboard", Route = "/admin/dashboard" });

			if (User.IsInRole("Staff"))
				return Ok(new { Target = "StaffDashboard", Route = "/staff/dashboard" });

			return Ok(new { Target = "ParentHome", Route = "/parent/home" });
		}

		// ==========================================
		// 4. TRỌN BỘ CRUD CHO USER[cite: 12]
		// ==========================================

		// 1. CREATE (POST)
		[HttpPost]
		[Authorize(Roles = "Admin")]
		public async Task<IActionResult> Create([FromBody] UserCreateDto dto)
		{
			var user = new IdentityUser { UserName = dto.Email, Email = dto.Email };
			var result = await _userManager.CreateAsync(user, dto.Password);
			if (!result.Succeeded) return BadRequest(result.Errors);

			await _userManager.AddToRoleAsync(user, dto.Role);
			return CreatedAtAction(nameof(GetById), new { id = user.Id }, user);
		}

		// 2. READ ALL (GET)
		[HttpGet]
		[Authorize(Roles = "Admin,Staff")]
		public async Task<IActionResult> GetAll()
		{
			var users = await _userManager.Users.ToListAsync();
			return Ok(users);
		}

		// READ BY ID (GET)
		[HttpGet("{id}")]
		public async Task<IActionResult> GetById(string id)
		{
			var user = await _userManager.FindByIdAsync(id);
			if (user == null) return NotFound("Không tìm thấy người dùng.");
			return Ok(user);
		}

		// 3. UPDATE (PUT)
		[HttpPut("{id}")]
		public async Task<IActionResult> Update(string id, [FromBody] UserUpdateDto dto)
		{
			var user = await _userManager.FindByIdAsync(id);
			if (user == null) return NotFound("Không tìm thấy người dùng.");

			user.Email = dto.Email;
			user.UserName = dto.Email;
			user.PhoneNumber = dto.PhoneNumber;

			var result = await _userManager.UpdateAsync(user);
			if (!result.Succeeded) return BadRequest(result.Errors);

			return Ok(user);
		}

		// 4. DELETE (DELETE)
		[HttpDelete("{id}")]
		[Authorize(Roles = "Admin")]
		public async Task<IActionResult> Delete(string id)
		{
			var user = await _userManager.FindByIdAsync(id);
			if (user == null) return NotFound("Không tìm thấy người dùng.");

			var result = await _userManager.DeleteAsync(user);
			if (!result.Succeeded) return BadRequest(result.Errors);

			return Ok(new { Message = "Xóa người dùng thành công." });
		}
	}
}