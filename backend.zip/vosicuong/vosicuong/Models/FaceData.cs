﻿using Microsoft.AspNetCore.Identity;

namespace vosicuong.Models
{
	public class FaceData
	{
		public int Id { get; set; }

		// Thay UserId từ int sang string để map với IdentityUser.Id
		public string UserId { get; set; } = string.Empty;
		public IdentityUser User { get; set; } = null!;

		public string FaceVector { get; set; } = string.Empty;
	}
}
