﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using vosicuong.Models;

namespace vosicuong.Data
{
	public class ApplicationDbContext : IdentityDbContext<IdentityUser>
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
			: base(options) { }

		public DbSet<ChildDevice> ChildDevices { get; set; }
		public DbSet<FaceData> FaceDatas { get; set; }
		public DbSet<ParentChildLink> ParentChildLinks => Set<ParentChildLink>();
		public DbSet<ParentChildInvitation> ParentChildInvitations => Set<ParentChildInvitation>();
		public DbSet<DeviceControlPolicy> DeviceControlPolicies => Set<DeviceControlPolicy>();
		public DbSet<AppControlRule> AppControlRules => Set<AppControlRule>();

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<FaceData>(entity =>
			{
				entity.HasKey(f => f.Id);
				entity.Property(f => f.UserId).IsRequired();
				entity.Property(f => f.FaceVector).IsRequired();

				entity.HasOne(f => f.User)
					.WithMany()
					.HasForeignKey(f => f.UserId)
					.OnDelete(DeleteBehavior.Cascade);

				entity.HasIndex(f => f.UserId).IsUnique();
			});

			modelBuilder.Entity<DeviceControlPolicy>()
				.HasIndex(x => x.ChildDeviceId)
				.IsUnique();

			modelBuilder.Entity<DeviceControlPolicy>()
				.HasOne(x => x.ChildDevice)
				.WithMany()
				.HasForeignKey(x => x.ChildDeviceId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<AppControlRule>()
				.HasIndex(x => new { x.ChildDeviceId, x.PackageName })
				.IsUnique();

			modelBuilder.Entity<AppControlRule>()
				.HasOne(x => x.ChildDevice)
				.WithMany()
				.HasForeignKey(x => x.ChildDeviceId)
				.OnDelete(DeleteBehavior.Cascade);

			modelBuilder.Entity<ParentChildLink>()
				.HasIndex(x => new { x.ParentId, x.ChildId })
				.IsUnique();

			modelBuilder.Entity<ParentChildLink>()
				.HasOne<IdentityUser>()
				.WithMany()
				.HasForeignKey(x => x.ParentId)
				.OnDelete(DeleteBehavior.Restrict);

			modelBuilder.Entity<ParentChildLink>()
				.HasOne<IdentityUser>()
				.WithMany()
				.HasForeignKey(x => x.ChildId)
				.OnDelete(DeleteBehavior.Restrict);

			modelBuilder.Entity<ParentChildInvitation>()
				.HasIndex(x => x.CodeHash)
				.IsUnique();

			modelBuilder.Entity<ParentChildInvitation>()
				.HasOne<IdentityUser>()
				.WithMany()
				.HasForeignKey(x => x.ParentId)
				.OnDelete(DeleteBehavior.Restrict);

			// Cho phép Child tự đăng ký thiết bị khi chưa liên kết với Parent.
			modelBuilder.Entity<ChildDevice>(entity =>
			{
				entity.HasOne(x => x.Parent)
					.WithMany()
					.HasForeignKey(x => x.ParentId)
					.IsRequired(false)
					.OnDelete(DeleteBehavior.Restrict);

				entity.HasOne(x => x.ChildUser)
					.WithMany()
					.HasForeignKey(x => x.ChildUserId)
					.IsRequired(false)
					.OnDelete(DeleteBehavior.Restrict);

				entity.HasIndex(x => x.ChildUserId)
					.IsUnique()
					.HasFilter("[ChildUserId] IS NOT NULL");
			});

			modelBuilder.Entity<IdentityRole>().HasData(
				new IdentityRole
				{
					Id = "1",
					Name = "Admin",
					NormalizedName = "ADMIN",
					ConcurrencyStamp = "c8f2887a-251d-4f1d-b873-198d02fa7b11"
				},
				new IdentityRole
				{
					Id = "2",
					Name = "Staff",
					NormalizedName = "STAFF",
					ConcurrencyStamp = "f4e3892a-392b-4d2c-a218-912b304f8c22"
				},
				new IdentityRole
				{
					Id = "3",
					Name = "Parent",
					NormalizedName = "PARENT",
					ConcurrencyStamp = "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d"
				},
				new IdentityRole
				{
					Id = "4",
					Name = "Child",
					NormalizedName = "CHILD",
					ConcurrencyStamp = "e9f8d7c6-b5a4-3f2e-1d0c-9b8a7f6e5d4c"
				}
			);
		}
	}
}
